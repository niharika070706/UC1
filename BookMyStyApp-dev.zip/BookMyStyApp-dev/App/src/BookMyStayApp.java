public class BookMyStayApp {
    public static void main(String[] args) {

        System.out.println("=================================");
        System.out.println(" Welcome to Book My Stay ");
        System.out.println(" Hotel Booking System v1.0 ");
        System.out.println("=================================");

        System.out.println("Application started successfully.");
        System.out.println("Thank you for using Book My Stay!");
        }
    }
}
